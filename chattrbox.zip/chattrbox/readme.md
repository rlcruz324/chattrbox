<!--
First you need to be able to run npm run dev. To do that install node.js
In Linux open the terminal and run 
sudo apt update
sudo apt install nodejs npm
node.js --version
In Windows download the installer from here https://nodejs.org/en/download/prebuilt-installer

Open Terminal(Linux) or command prompt(Windows) and run
npm run dev
This will start the server
Next open yours browser (Textbook uses Chrome. It also works in Firefox.) and go to
http://localhost:3000/
Enter one of the following emails I used for icons. If you use a random username there wont be icons.
zzombiebunny@proton.me
sweetboogiemonster@proton.me
sweeetbanshee@proton.me
Open another tab to localhost to communicate through it. 

As far as the code goes app has the actual code we will be editing. The websockets-server.js is also important. Its there the messsage (msg) stuff is saved as a array instead of a database. The rest is dependency stuff. Don't touch that maybe? 

Below were my old comments to myself. Looks like a list of dependencies. 
-->




<!-------------------------------------------------------------------------------------------------------------------------->
<!-- 
Notes:
cd c:\Users\rlcruz324\Desktop\test\chattrbox
npm init 
^ create package.json
npm install --save-dev nodemon

npm install --save ws
^ save websockets

npm install -g wscat

followed babel instructions to download latest version instead of textbook

npm install --save-dev browserify babelify watchify

npm install --save-dev jquery

npm install --save-dev crypto-js

npm install --save-dev moment

babel app/scripts/src/app.js -o app/scripts/dist/main.js 
^ test run code if nothing in terminal that is good sign

package.json contains important code
^code in json deviates from textbook in order to run

index.js contains code to http module and server.listen 
app.js contains ChatApp which is responsible for most application logic
-->